import './TelemetryPanel.css';
import type { RAGState } from '../App';

interface Props {
  state: RAGState;
}

export default function TelemetryPanel({ state }: Props) {
  const scorePercent = Math.round(state.grounding_score * 100);

  let scoreRange = 'high';
  if (state.grounding_score < 0.4) scoreRange = 'low';
  else if (state.grounding_score < 0.7) scoreRange = 'med';

  const getStatusClass = () => {
    switch (state.status) {
      case 'IDLE': return 'idle';
      case 'ERROR': return 'error';
      default: return 'active';
    }
  };

  const getStatusText = () => {
    switch (state.status) {
      case 'IDLE': return 'Ready';
      case 'ERROR': return 'Error';
      case 'PROCESSING': return 'Processing...';
      case 'UPLOADING': return 'Uploading...';
      default: return 'Unknown';
    }
  };

  return (
    <div className="telemetry-wrapper">
      {/* Status Card */}
      <div className="telemetry-card">
        <div className="card-title">System Status</div>
        <div className={`status-indicator ${getStatusClass()}`}>
          <span className="status-icon"></span>
          <span className="status-text">{getStatusText()}</span>
        </div>
      </div>

      {/* Metrics Card */}
      <div className="telemetry-card">
        <div className="card-title">Metrics</div>
        <div className="metrics-list">
          <div className="metric-item">
            <span className="metric-name">Healing Cycles</span>
            <span className="metric-data">{state.retry_count}<span className="metric-data small"> / 3</span></span>
          </div>

          <div className="metric-item">
            <span className="metric-name">Context Chunks</span>
            <span className="metric-data">{state.chunks_retrieved}</span>
          </div>

          <div className="metric-item" style={{ flexDirection: 'column', alignItems: 'flex-start', gap: '8px' }}>
            <span className="metric-name">Grounding Score</span>
            <div className="progress-container">
              <div className="progress-label">
                <span>{scorePercent}%</span>
              </div>
              <div className="progress-track">
                <div
                  className={`progress-bar ${scoreRange}`}
                  style={{ width: `${scorePercent}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Session Card */}
      <div className="telemetry-card">
        <div className="card-title">Session</div>
        <div className="session-display">
          {state.session_id}
        </div>
      </div>

      {/* Activity Card */}
      <div className="telemetry-card">
        <div className="card-title">Activity</div>
        <div className="activity-list">
          <div className="activity-item">System initialized</div>
          <div className="activity-item">Vector store connected</div>
          {state.status !== 'IDLE' && (
            <div className="activity-item active">
              {state.status === 'PROCESSING' ? 'Processing query...' : 'Uploading document...'}
            </div>
          )}
          {state.retry_count > 0 && (
            <div className="activity-item warning">
              Healing cycle {state.retry_count} triggered
            </div>
          )}
        </div>
      </div>
    </div>
  );
}