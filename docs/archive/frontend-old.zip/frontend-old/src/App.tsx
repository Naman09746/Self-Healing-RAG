import { useState } from 'react';
import './App.css';
import ChatInterface from './components/ChatInterface';
import TelemetryPanel from './components/TelemetryPanel';
import Login from './components/Login';

export interface RAGState {
  query: string;
  answer: string | null;
  status: string;
  retry_count: number;
  grounding_score: number;
  chunks_retrieved: number;
  session_id: string;
}

function App() {
  const [token, setToken] = useState<string | null>(localStorage.getItem('nexus_token'));
  const [sessionState, setSessionState] = useState<RAGState>({
    query: '',
    answer: null,
    status: 'IDLE',
    retry_count: 0,
    grounding_score: 0,
    chunks_retrieved: 0,
    session_id: crypto.randomUUID()
  });

  const handleLogin = (newToken: string) => {
    localStorage.setItem('nexus_token', newToken);
    setToken(newToken);
  };

  const handleLogout = () => {
    localStorage.removeItem('nexus_token');
    setToken(null);
  };

  if (!token) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <>
      <div className="brand-header">
        <h1 className="brand-title">Nexus Core</h1>
        <span className="brand-subtitle">WORKSPACE ENVIRONMENT</span>
        <button className="logout-button" onClick={handleLogout}>
          Sign Out
        </button>
      </div>

      <div className="dashboard-container">
        <main className="interaction-zone">
          <ChatInterface 
            sessionState={sessionState} 
            setSessionState={setSessionState}
            token={token}
            onUnauthorized={handleLogout}
          />
        </main>

        <aside className="telemetry-sidebar">
          <TelemetryPanel state={sessionState} />
        </aside>
      </div>
    </>
  );
}

export default App;