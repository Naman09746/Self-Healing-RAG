import { useState, useRef, useEffect } from 'react';
import './ChatInterface.css';
import type { RAGState } from '../App';
import { queryRAG, uploadFile } from '../api/client';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
}

interface Props {
  sessionState: RAGState;
  setSessionState: React.Dispatch<React.SetStateAction<RAGState>>;
  token: string;
  onUnauthorized: () => void;
}

export default function ChatInterface({ sessionState, setSessionState, token, onUnauthorized }: Props) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isTyping) return;

    const userMessage: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      content: input.trim()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    try {
      const response = await queryRAG(userMessage.content, sessionState.session_id, token);

      const assistantMessage: ChatMessage = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: response.answer
      };

      setMessages(prev => [...prev, assistantMessage]);
      setSessionState(prev => ({
        ...prev,
        ...response,
        status: 'IDLE'
      }));

    } catch (error: any) {
      if (error.message === 'Unauthorized') {
        onUnauthorized();
        return;
      }
      const errorMessage: ChatMessage = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: 'Connection failed. Please ensure the backend is running.'
      };
      setMessages(prev => [...prev, errorMessage]);
      setSessionState(prev => ({ ...prev, status: 'ERROR' }));
    } finally {
      setIsTyping(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    setSessionState(prev => ({ ...prev, status: 'UPLOADING' }));

    try {
      await uploadFile(file, token);
      const systemMessage: ChatMessage = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: `Document "${file.name}" has been indexed and added to the knowledge base.`
      };
      setMessages(prev => [...prev, systemMessage]);
      setSessionState(prev => ({ ...prev, status: 'IDLE' }));
    } catch (error: any) {
      if (error.message === 'Unauthorized') {
        onUnauthorized();
        return;
      }
      const errorMessage: ChatMessage = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: `Failed to upload "${file.name}". Please try again.`
      };
      setMessages(prev => [...prev, errorMessage]);
      setSessionState(prev => ({ ...prev, status: 'ERROR' }));
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const isEmpty = messages.length === 0;

  return (
    <div className="chat-wrapper">
      <div className={`messages-container ${isEmpty ? 'empty' : ''}`}>
        {messages.map((msg) => (
          <div key={msg.id} className={`chat-message ${msg.role}`}>
            <div className="message-label">
              {msg.role === 'user' ? 'You' : 'Nexus'}
            </div>
            <div className="message-bubble">
              {msg.content}
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="typing-wrapper">
            <div className="typing-dots">
              <span className="typing-dot"></span>
              <span className="typing-dot"></span>
              <span className="typing-dot"></span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      <div className="input-wrapper">
        <form className="input-form" onSubmit={handleSubmit}>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept=".txt,.pdf,.docx"
          />
          <button
            type="button"
            className="upload-btn"
            onClick={() => fileInputRef.current?.click()}
            disabled={isTyping || isUploading}
            title="Upload document"
          >
            +
          </button>
          <input
            type="text"
            className="chat-input"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask something..."
            disabled={isTyping || isUploading}
          />
          <button
            type="submit"
            className="send-btn"
            disabled={isTyping || isUploading || !input.trim()}
            title="Send message"
          >
            →
          </button>
        </form>
      </div>
    </div>
  );
}